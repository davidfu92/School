import java.io.*;
import java.net.*;

public class EchoClient {
    public static void main(String[] args) throws IOException {

        if (args.length > 1)
        {
            //Parse arguments
        }else {
            //Exit the program
        }
        
        //Initialize socket
        //Initialize printwriter
        //Initialize bufferedreader
        //Initialize bufferedreader for user input

	while (/* user input */!= null) {
	    //Send user input to server
        //Read server input
        //Print server input
	}

        //Close all the sockets and buffers.
    }
}
